# Live deployed prototype

Required: a deployed prototype link that remains available throughout evaluation. Status: not deployed. Billing linkage alone does not verify funded coverage or authorize execution.

Start with the [step-by-step HTML resource/setup guide](resource-setup-guide.html): naming inventory, dependency order, PowerShell command examples, IAM boundaries, cloud configuration, deployment checks and recovery. It is an offline reference, not a cloud installer. Proposed resource names and blocked source-publication work are explicit.

- [x] Prepare the resource naming and setup/deployment HTML runbook.

- [x] Track the existing disabled deployment preparation: [configuration](../../config/deployment.example.json) and [recovery instructions](../../docs/deployment-recovery.md).
- [ ] Verify funding/service coverage, cloud model/location, runtime identities and operator/admin access.
- [ ] Build and validate the web/private-worker images; deploy only after the execution gates are cleared.
- [ ] Record actual deployed revision IDs and a working public HTTPS prototype URL.
- [ ] Check signed-out evidence/usage reads, operator sign-in and private output protection; verify the genuine workflow.
- [ ] Confirm the official evaluation availability window and the plan to keep the service healthy within verified coverage.
- [ ] Recheck the URL before submission and during evaluation; public browsing must not trigger model calls.

Public prototype URL: **Pending**.

Web/private-worker revision IDs: **Pending**.

Evaluation availability window and health-check responsibility: **Pending**.

Access/recovery evidence: **Pending**.
