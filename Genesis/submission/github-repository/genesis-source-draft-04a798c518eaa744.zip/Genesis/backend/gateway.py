"""The only model transport boundary. No SDK is loaded on the refusing path."""
from dataclasses import dataclass
import json
import os
import re
from time import monotonic

from pydantic import BaseModel, ValidationError


@dataclass(frozen=True)
class GatewayResult:
    outcome: str = "NOT_SENT"
    error_code: str | None = "AI_NOT_CONNECTED"
    output: dict | None = None
    step_id: str | None = None


def call_model(settings, **_request) -> GatewayResult:
    # Compatibility refusal probe; real opt-in work uses generate_json in workers.
    return GatewayResult()


def _provider_client(settings):
    if not settings.ai_authorized():
        from .repository import Conflict
        raise Conflict("AI_NOT_CONNECTED")
    from google import genai
    from google.genai import types
    if settings.mode == "cloud":
        return genai.Client(enterprise=True, project=settings.project_id, location=settings.verified_cloud_location,
            http_options=types.HttpOptions(api_version="v1", timeout=30000, retry_options=types.HttpRetryOptions(attempts=1)))
    return genai.Client(enterprise=False, api_key=os.environ["GEMINI_API_KEY"].strip(),
        http_options=types.HttpOptions(base_url="https://generativelanguage.googleapis.com", api_version="v1beta",
            timeout=30000, retry_options=types.HttpRetryOptions(attempts=1)))


def _retry_delay(exc):
    if getattr(exc, "code", None) != 429 or getattr(exc, "status", None) != "RESOURCE_EXHAUSTED": return None
    body = getattr(exc, "details", None)
    if not isinstance(body, dict): return None
    error = body.get("error", body)
    details = error.get("details") if isinstance(error, dict) else None
    if not isinstance(details, list) or len(details) != 1 or not isinstance(details[0], dict): return None
    # Only explicit short RetryInfo, with no quota/billing/other failure details.
    info = details[0]
    delay = info.get("retryDelay")
    if info.get("@type") != "type.googleapis.com/google.rpc.RetryInfo" or not isinstance(delay, str): return None
    if not re.fullmatch(r"[0-5](?:\.[0-9]{1,9})?s", delay): return None
    seconds = float(delay[:-1])
    return max(1, seconds) if seconds <= 5 else None


def generate_json(repo, step, prompt: str, schema: type[BaseModel], *, input_limit: int, output_limit: int, evidence: dict | None = None):
    """One explicitly authorized provider attempt; no SDK retries or fallback."""
    from .repository import Conflict, now
    from .dataset import content_hash
    if not repo.settings.ai_authorized(): return GatewayResult()
    if repo.settings.mode == "cloud" and not step.worker_lease: return GatewayResult(error_code="WORKER_LEASE_REQUIRED")
    if step.leg_id in {"A2", "A3", "A4", "A5"} and evidence is None: return GatewayResult(error_code="EVIDENCE_REQUIRED")
    if not repo.daily_control()["live_enabled"]: return GatewayResult(error_code="LIVE_AI_DISABLED")
    # Schema and instructions are in the exact text counted and sent. JSON mode
    # constrains syntax; Pydantic (plus the caller's grounding checks) validates it.
    contents = json.dumps({"instruction": prompt, "output_schema": schema.model_json_schema()}, separators=(",", ":"))
    if len(contents) > 100000 or not 1 <= input_limit <= 8192 or not 1 <= output_limit <= 3072:
        return GatewayResult(error_code="REQUEST_LIMIT")
    reserved = False
    clock = monotonic()
    usage = {}
    try:
        if step.worker_lease: repo.check_worker_lease(step.worker_lease, reserve_seconds=65)
        with _provider_client(repo.settings) as client:
            count = client.models.count_tokens(model=repo.settings.active_model_id, contents=contents).total_tokens
            if type(count) is not int or count < 0: return GatewayResult(error_code="PRECOUNT_UNAVAILABLE")
            if count > input_limit: return GatewayResult(error_code="CONTEXT_LIMIT")
            step = step.model_copy(update={"context_precount_tokens": count, "input_snapshot": {"contents": contents}, "input_hash": content_hash(contents)})
            if not repo.reserve_model_attempt(step): return GatewayResult(error_code="ATTEMPT_ALREADY_RESERVED", step_id=step.id)
            reserved = True
            response = client.models.generate_content(model=repo.settings.active_model_id, contents=contents,
                config={"response_mime_type": "application/json", "max_output_tokens": output_limit,
                    "thinking_config": {"thinking_level": "MINIMAL"}, "automatic_function_calling": {"disable": True}})
            metadata = response.usage_metadata
            fields = {"prompt_tokens": "prompt_token_count", "cached_prompt_tokens": "cached_content_token_count",
                "candidate_tokens": "candidates_token_count", "thought_tokens": "thoughts_token_count",
                "tool_prompt_tokens": "tool_use_prompt_token_count", "total_tokens": "total_token_count"}
            usage = {key: value if type(value := getattr(metadata, name, None)) is int and value >= 0 else None for key, name in fields.items()}
            usage.update({"usage_status": "PROVIDER_REPORTED" if any(value is not None for value in usage.values()) else "UNKNOWN",
                "provider_usage_raw": {key: value for key, value in usage.items() if value is not None},
                "provider_request_id": str(response.response_id)[:128] if response.response_id else None})
            parsed = schema.model_validate_json(response.text or "")
            result = parsed.model_dump(mode="json")
            validation = {"schema_pass": True}
            if evidence is not None:
                from .validation import validate_model_output
                try: findings = validate_model_output(parsed, evidence)
                except ValueError as exc: raise ValidationBoundaryError() from exc
                validation.update({key: value for key, value in findings.items() if key != "output"})
                validation["evidence_pass"] = True
            accepted = repo.seal_provider_attempt(step, {**usage, "state": "SUCCEEDED", "output": result,
                "validation": validation, "execution_provenance": "REAL_PROVIDER", "finished_at": now(), "duration_ms": int((monotonic() - clock) * 1000),
                "error_code": None})
            if not accepted: return GatewayResult(outcome="UNKNOWN_OUTCOME", error_code="ATTEMPT_ALREADY_SEALED", step_id=step.id)
            return GatewayResult(outcome="SUCCEEDED", error_code=None, output=result, step_id=step.id)
    except Conflict as exc:
        return GatewayResult(outcome="UNKNOWN_OUTCOME" if reserved else "NOT_SENT", error_code=str(exc), step_id=step.id if reserved else None)
    except Exception as exc:
        # Exception strings can contain prompts, headers or keys: never store them.
        code = getattr(exc, "code", None)
        invalid = isinstance(exc, (ValidationError, ValidationBoundaryError)) and bool(usage)
        rejected = type(code) is int and 400 <= code < 500 and code != 408
        error = "OUTPUT_INVALID" if invalid else f"PROVIDER_HTTP_{code}" if type(code) is int and 400 <= code <= 599 else "PROVIDER_OUTCOME_UNKNOWN"
        if reserved:
            accepted = repo.seal_provider_attempt(step, {**usage,
                "state": "FAILED" if invalid or rejected else "UNKNOWN_OUTCOME", "output": None,
                "execution_provenance": "REAL_PROVIDER" if invalid or rejected else "UNKNOWN",
                "retry_delay_seconds": _retry_delay(exc) if rejected else None,
                "error_code": error, "finished_at": now(), "duration_ms": int((monotonic() - clock) * 1000)})
            if not accepted: return GatewayResult(outcome="UNKNOWN_OUTCOME", error_code="ATTEMPT_ALREADY_SEALED", step_id=step.id)
        return GatewayResult(outcome="FAILED" if invalid or rejected else "UNKNOWN_OUTCOME" if reserved else "NOT_SENT", error_code=error, step_id=step.id if reserved else None)


class ValidationBoundaryError(ValueError):
    """A grounded-output check failed; no provider text is exposed."""
