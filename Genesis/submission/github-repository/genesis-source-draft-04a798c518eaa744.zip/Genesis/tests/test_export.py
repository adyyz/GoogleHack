"""Source archive boundaries; credentials below are synthetic in-memory fixtures."""
import hashlib
import io
import json
import zipfile

import pytest

from scripts.export_source import archive_bytes, source_files


def test_export_allowlist_excludes_private_material_and_pins_exact_sources(tmp_path):
    names = {"README.md": b"Draft", "backend/api.py": b"pass\n", "frontend/index.html": b"<main>Demo</main>",
        ".env.example": b"LIVE_AI_ENABLED=false\n", "config/deployment.example.json": b"{}",
        "context/internal.md": b"private plan", ".env": b"private environment", ".codex/config.toml": b"private path",
        ".cache/emulator-data.json": b"private evidence", "backend/credentials.json": b"private credentials",
        "docs/analyst-notes.md": b"private notes", "AGENTS.md": b"internal references"}
    for name, data in names.items():
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    files = source_files(tmp_path, list(names))
    assert set(files) == {"README.md", "backend/api.py", "frontend/index.html", ".env.example", "config/deployment.example.json"}
    record = {"source": {"base_revision": "unit-revision", "uncommitted_worktree": True, "code_fingerprint": "unit-hash"},
        "checks": {}, "local_provenance": {"manifest_hash": "unit-source-manifest"}}
    data = archive_bytes(files, record)
    assert data == archive_bytes(dict(reversed(list(files.items()))), record)
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert set(archive.namelist()) == {"Genesis/" + name for name in [*files, "release-manifest.json"]}
        manifest = json.loads(archive.read("Genesis/release-manifest.json"))
        assert manifest["status"] == "PREPARATION_ONLY" and not manifest["publication_authorized"] and not manifest["release_ready"]
        assert manifest["files"] == {name: hashlib.sha256(content).hexdigest() for name, content in files.items()}
        assert all(archive.read("Genesis/" + name) == content for name, content in files.items())
    for name in ["../README.md", "C:/README.md", "backend\\api.py"]:
        with pytest.raises(ValueError, match="Invalid source path"): source_files(tmp_path, [name])
    for credential in [b"AIza" + b"a" * 35, b"ya29." + b"a" * 25, b"-----BEGIN " + b"PRIVATE KEY-----"]:
        (tmp_path / "backend/api.py").write_bytes(credential)
        with pytest.raises(ValueError, match="Credential pattern"): source_files(tmp_path, ["backend/api.py"])
