// All cloud-shaped responses below are intercepted display/auth faults only.
const assert = require('node:assert/strict');
const { expect } = require('@playwright/test');

module.exports = async function checkSignIn(browser) {
  const context = await browser.newContext({ viewport: { width: 390, height: 740 }, reducedMotion: 'reduce' });
  try {
    const page = await context.newPage();
    let config = { mode: 'cloud', auth_emulator_url: null, firebase_web_api_key: null };
    let configFailure = true;
    let authCalls = 0;
    let sessionCalls = 0;
    let sessionCode = 403;
    let releaseConfig;
    let slowConfig = false;
    await page.route('**/api/config', async route => {
      if (slowConfig) await new Promise(resolve => { releaseConfig = resolve; });
      await route.fulfill({ status: configFailure ? 503 : 200, json: configFailure ? { detail: 'Unavailable' } : config }).catch(() => {});
    });
    // Intercept on the browser context so no real Google request can leave it.
    await context.route('https://identitytoolkit.googleapis.com/**', async route => {
      const request = route.request();
      if (request.method() === 'OPTIONS') {
        return route.fulfill({ status: 204, headers: { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'content-type' } });
      }
      authCalls++;
      assert.equal(request.method(), 'POST');
      const body = request.postDataJSON();
      assert.equal(body.email, 'cloud-operator@example.test');
      assert.equal(body.password, 'test-only-password');
      assert.equal(body.returnSecureToken, true);
      assert(!request.url().includes('cloud-operator') && !request.url().includes('test-only-password'));
      await route.fulfill({ status: authCalls === 1 ? 400 : 200,
        headers: { 'Access-Control-Allow-Origin': '*' },
        json: authCalls === 1 ? { error: { message: 'PRIVATE_PROVIDER_MESSAGE' } } : { idToken: 'test-only-not-a-real-token' } });
    });
    await page.route('**/api/operator/session', async route => {
      sessionCalls++;
      assert.equal(route.request().headers().authorization, 'Bearer test-only-not-a-real-token');
      await route.fulfill({ status: sessionCode, json: { detail: sessionCode === 403 ? 'Operator account is not allowlisted' : 'Invalid or expired operator token' } });
    });
    await page.goto('http://127.0.0.1:8080');
    await page.getByRole('heading', { name: 'Investigations', exact: true }).waitFor();
    const trigger = page.getByRole('button', { name: /Public visitor/ });
    await trigger.click();
    await page.getByText('Unable to load sign-in. Check your connection and retry.', { exact: true }).waitFor();
    configFailure = false;
    await page.getByRole('button', { name: 'Retry sign-in setup' }).click();
    await page.getByText('Operator sign-in is not configured. Contact the administrator.', { exact: true }).waitFor();
    await expect(page.getByLabel('Email', { exact: true })).toHaveValue('');
    await expect(page.getByLabel('Password', { exact: true })).toHaveValue('');
    await expect(page.getByRole('button', { name: 'Sign in', exact: true })).toBeDisabled();
    assert.equal(authCalls, 0);
    config = { ...config, firebase_web_api_key: 'public-firebase-test-configuration' };
    await page.getByRole('button', { name: 'Retry sign-in setup' }).click();
    await expect(page.getByRole('button', { name: 'Sign in', exact: true })).toBeEnabled();
    await page.getByLabel('Email', { exact: true }).fill('cloud-operator@example.test');
    await page.getByLabel('Password', { exact: true }).fill('test-only-password');
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
    await page.getByText('Sign-in failed. Check your email and password, then retry.', { exact: true }).waitFor();
    assert.equal(await page.getByText('PRIVATE_PROVIDER_MESSAGE').count(), 0);
    assert.equal(sessionCalls, 0);
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
    await page.getByText('Operator account is not allowlisted', { exact: true }).waitFor();
    await expect(trigger).toBeVisible();
    await expect(page.getByLabel('Email', { exact: true })).toHaveValue('cloud-operator@example.test');
    sessionCode = 401;
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
    await page.getByText('Invalid or expired operator token', { exact: true }).waitFor();
    await page.getByRole('dialog').getByLabel('Email', { exact: true }).focus();
    await page.keyboard.press('Tab');
    assert(await page.getByRole('dialog').evaluate(dialog => dialog.contains(document.activeElement)));
    await page.screenshot({ path: '.cache/preview/cloud-signin-fault.png' });
    assert.deepEqual(await page.evaluate(() => [localStorage.length, sessionStorage.length]), [0, 0]);
    assert.equal(new URL(page.url()).search, '');
    await page.keyboard.press('Escape');
    await expect(trigger).toBeFocused();
    slowConfig = true;
    await trigger.click();
    await expect(page.getByRole('button', { name: 'Verifying…', exact: true })).toBeDisabled();
    await expect.poll(() => !!releaseConfig).toBe(true);
    await page.keyboard.press('Escape');
    releaseConfig();
    await expect(page.getByRole('dialog')).toHaveCount(0);
    assert.equal(authCalls, 3);
    assert.equal(sessionCalls, 2);
    console.log('Cloud sign-in preparation passed: missing/offline configuration, empty credentials, generic rejection, server 403/401, keyboard focus, mobile and cancelled setup. Google responses were intercepted; no cloud session established.');
  } finally { await context.close(); }
};
