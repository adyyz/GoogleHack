"""Capture local check artifacts; never promote test fixtures to live evidence."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def code_fingerprint():
    names = subprocess.check_output(["git", "ls-files", "-c", "-o", "--exclude-standard", "--", "."], cwd=ROOT, text=True).splitlines()
    hashes = {}
    roots = {"backend", "frontend", "tests", "scripts", "config"}
    files = {"Dockerfile", ".dockerignore", "pyproject.toml", "uv.lock", "package.json", "package-lock.json", "firebase.json", "firestore.rules", "firestore.indexes.json", ".env.example", "tsconfig.json", "vite.config.ts"}
    for name in sorted(set(names)):
        path = ROOT / name
        if Path(name).parts[0] not in roots and name not in files: continue
        if not path.resolve().is_relative_to(ROOT): raise ValueError("Source path escapes Genesis")
        if path.is_file(): hashes[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return hashlib.sha256(json.dumps(hashes, sort_keys=True).encode()).hexdigest()


def junit_summary(path):
    cases = list(ET.parse(path).getroot().iter("testcase"))
    if not cases: raise ValueError("Missing test cases")
    skipped = sum(case.find("skipped") is not None for case in cases)
    failed = sum(case.find("failure") is not None or case.find("error") is not None for case in cases)
    return {"total": len(cases), "passed": len(cases) - skipped - failed, "skipped": skipped, "failed": failed,
        "artifact_hash": hashlib.sha256(path.read_bytes()).hexdigest()}


def capture():
    def read(name): return json.loads((ROOT / ".cache" / name).read_text(encoding="utf-8-sig"))
    provenance = read("integration-provenance.json")
    fingerprint = code_fingerprint()
    if provenance["code_fingerprint"] != fingerprint: raise ValueError("Source changed since integration verification")
    unit = junit_summary(ROOT / ".cache/unit-results.xml")
    integration = junit_summary(ROOT / ".cache/integration-results.xml")
    if unit["failed"] or integration["failed"] or integration["skipped"]:
        raise ValueError("Local verification is incomplete")
    python = read("python-audit.json")
    npm = read("npm-audit.json")
    production = read("npm-production-audit.json")
    python_findings = [{"name": row["name"], "version": row["version"], "vulnerabilities": row["vulns"]}
        for row in python["dependencies"] if row.get("vulns")]
    smoke_path = ROOT / ".cache/gemini-smoke-result.json"
    smoke = json.loads(smoke_path.read_text(encoding="utf-8-sig")) if smoke_path.exists() else {}
    smoke_fields = ("purpose", "run_id", "step_id", "model", "state", "schema_pass", "provider_reported_tokens",
        "prompt_tokens", "candidate_tokens", "generation_attempts", "live_enabled_after_check", "cost_status", "completed_at")
    record = {"schema_version": 1, "status": "LOCAL_VERIFICATION_ONLY", "recorded_at": datetime.now(timezone.utc).isoformat(),
        "source": {"base_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
            "uncommitted_worktree": bool(subprocess.check_output(["git", "status", "--porcelain", "--", "."], cwd=ROOT, text=True).strip()),
            "code_fingerprint": fingerprint, "release_revision": None},
        "local_provenance": provenance, "checks": {"unit": unit, "emulator_integration": integration},
        "dependencies": {"python_packages_checked": len(python["dependencies"]), "python_findings": python_findings,
            "python_skipped": [row for row in python["dependencies"] if row.get("skip_reason")],
            "npm_production": production["metadata"]["vulnerabilities"], "npm_development_inclusive": npm["metadata"]["vulnerabilities"],
            "development_findings": [{"package": name, "severity": row["severity"]} for name, row in npm["vulnerabilities"].items()],
            "scope": "Installed Windows Python environment and npm lock; deployed image audit is pending"},
        "connectivity_only": {key: smoke[key] for key in smoke_fields if key in smoke},
        "release_evidence": {"genuine_investigation_run_id": None, "manual_citation_grounding": None,
            "human_feedback_event_ids": [], "genuine_a5_run_id": None, "frozen_candidate_hash": None,
            "heldout_comparison_id": None, "deployed_revision_ids": [], "signed_out_demo_url": None,
            "public_repository_url": None, "pdf_deck_url": None, "video_url": None, "video_duration_seconds": None,
            "official_eligibility_and_cutoff": None},
        "limitations": ["Local fault/authorization fixtures are not live model or human evidence.",
            "Connectivity smoke is not an AML investigation. Cost remains unknown.",
            "No held-out comparison or optimization performance claim is established.",
            "Funding coverage, cloud identities and publication/submission destinations remain unverified.",
            "This record does not authorize deployment, billing activation or live requests."], "release_ready": False}
    target = ROOT / "docs/evaluation-record.json"
    target.write_text(json.dumps(record, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"record": "docs/evaluation-record.json", "status": record["status"], "release_ready": False}))


if __name__ == "__main__": capture()
