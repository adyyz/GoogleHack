# Updated Genesis build candidate

PREPARED_NOT_SUBMITTED. Source fingerprint: afaa79bb9e71047c64a91bb67c96c7558e432874947d9bd7611fc6d0745b1e00.
Local validation:81 unit passes;11 fresh emulator integration passes,zero integration skips;
frontend production build and browser journeys passed. These are not new Linux image results.
The previous6cd03 build and digests remain historical and unchanged.

This candidate reuses the verified user-managed build identity, Sydney image registry,
four-step build/integrity/network-isolated-smoke configuration, E2_STANDARD_2 and1200s timeout.
No model key, credentials, caches, internal context, local dashboard or source data is included.
Run verify-package.py locally to check all files. New image digests are unknown until a new
explicitly approved build succeeds. No build, deployment or model request has been submitted.
The previous one-build approval has been consumed. See next-deployment-plan.json in the
private Genesis .cache/build directory for the proposed bounded staging scope and cost gates.
