import React, { useEffect, useRef, useState } from 'react';
import { request } from './api';
import { Dialog } from './Dialog';
import { Icon } from './Icon';
import { CaseStages } from './CaseStages';
import { syntheticLabel } from './bulk-label';
import { UsageDisplay } from './Usage';
import { AgentTrace } from './AgentTrace';
import { OperatorReview } from './OperatorReview';
import type { CaseRecord, PrivateAlert, RunDetail, UsageSummary, EvolutionDetail } from './types';

type Row = { id: string; identity_id: string; name: string; customer_type: string; rules: string[]; heuristic_score: number; requires_review: boolean; risk_tier: string; triaged?: boolean; reviewed?: boolean };
type Page = { items: Row[]; total: number; next_cursor: number | null };
type Summary = { transactions: number; identities: number; cases: number; eligible_pending_cases: number; reference_annotations: number; rule_alerts: Record<string, number>; training_detector_metrics: { TP: number; FP: number; TN: number; FN: number; inconclusive: number }; policy: { policy_id: string; rules: Record<string, { tp: number; fp: number }> } };
type Preview = { case_ids?: string[]; selection_hash: string; dataset_id: string; eligible_cases: number; alerts: number; minimum_generation_attempts: number; maximum_generation_attempts: number; authorization_available: boolean };
type Job = { id: string; state: string; revision: number; counts: Record<string, number>; members: { case_id: string; state: string; parent_id: string | null; error_code?: string }[] };
type Learning = { id: string; revision: number; state: string; body: { results: { rule_id: string; sample_size: number; status: string; generator_target_met: boolean }[] }; validation: { results: { rule_id: string; passed: boolean }[] } | null };
const names = (s: string) => s.toLowerCase().replaceAll('_', ' ');

export function BulkWorkspace({ token, navigate, onError, onDirty, onRun, onComplete }: { token: string; navigate: (fn: () => void) => void; onError: (e: unknown) => void; onDirty: (value: boolean) => void; onRun: (id: string) => void; onComplete: (run: RunDetail) => void }) {
  const [batchHistory, setBatchHistory] = useState<{ id: string; state: string }[]>([]);
  const [reportHistory, setReportHistory] = useState<{ id: string; state: string }[]>([]);
  const [learningHistory, setLearningHistory] = useState<Learning[]>([]);
  const [accounting, setAccounting] = useState<UsageSummary | null>(null);
  const [snapshotId, setSnapshotId] = useState('');
  const [report, setReport] = useState<EvolutionDetail | null>(null);
  const [summary, setSummary] = useState<Summary | null>(null), [page, setPage] = useState<Page | null>(null);
  const [identities, setIdentities] = useState<{ identity_id: string; name: string; customer_type: string }[]>([]);
  const [selected, setSelected] = useState(''), [current, setCurrent] = useState<CaseRecord | null>(null);
  const [query, setQuery] = useState(''), [type, setType] = useState(''), [identity, setIdentity] = useState(''), [rule, setRule] = useState('');
  const [triageStatus, setTriageStatus] = useState('all');
  const [cursor, setCursor] = useState(0), [previous, setPrevious] = useState<number[]>([]);
  const [size, setSize] = useState(10), [busy, setBusy] = useState(''), [message, setMessage] = useState('');
  const [preview, setPreview] = useState<{ rows: Row[]; live: Preview | null; single: boolean; key: string } | null>(null);
  const [job, setJob] = useState<Job | null>(null), [learning, setLearning] = useState<Learning | null>(null);
  const [confirmation, setConfirmation] = useState<{ title: string; action: () => Promise<void> } | null>(null);
  const [predictions, setPredictions] = useState<Record<string, Record<string, string>>>({});
  const [version, setVersion] = useState(0), [genuine, setGenuine] = useState({ triaged_cases: 0, reviewed_cases: 0, triaged_alerts: 0, reviewed_alerts: 0, true_positive: 0, false_positive: 0, inconclusive: 0 });
  const reviewedRevisions = useRef(new Map<string, number>());
  const live = useRef(true); useEffect(() => { live.current = true; return () => { live.current = false; }; }, []);
  const session = useRef(token); session.current = token;
  useEffect(() => { setPreview(null); setJob(null); setLearning(null); setCurrent(null); setBusy(''); setSnapshotId(''); setReport(null); setAccounting(null); setBatchHistory([]); setReportHistory([]); setLearningHistory([]); }, [token]);
  useEffect(() => {
    const abort = new AbortController();
    request<{ items: typeof identities }>('/api/demo/bulk/identities', '', { signal: abort.signal }).then(value => setIdentities(value.items)).catch(e => { if (!abort.signal.aborted) onError(e); });
    request<Summary>('/api/demo/bulk/summary', '', { signal: abort.signal }).then(setSummary).catch(e => { if (!abort.signal.aborted) onError(e); });
    if (token) {
      request<{items: typeof batchHistory}>('/api/operator/triage-batches?limit=50', token, { signal: abort.signal }).then(value => { if (!abort.signal.aborted) setBatchHistory(value.items); }).catch(e => { if (!abort.signal.aborted) onError(e); });
      request<{items: typeof reportHistory}>('/api/operator/bulk/reports?limit=50', token, { signal: abort.signal }).then(value => { if (!abort.signal.aborted) setReportHistory(value.items); }).catch(e => { if (!abort.signal.aborted) onError(e); });
      request<{items: Learning[]}>('/api/operator/bulk/learning?limit=50', token, { signal: abort.signal }).then(value => { if (!abort.signal.aborted) setLearningHistory(value.items); }).catch(e => { if (!abort.signal.aborted) onError(e); });
    }
    if (token) request<UsageSummary>('/api/operator/bulk/usage', token, { signal: abort.signal }).then(setAccounting).catch(e => { if (!abort.signal.aborted) onError(e); });
    if (token) request<typeof genuine>('/api/operator/bulk/summary', token, { signal: abort.signal }).then(setGenuine).catch(e => { if (!abort.signal.aborted) onError(e); });
    return () => abort.abort();
  }, [token, version]);
  function parameters(limit = 50, at = cursor) { return new URLSearchParams({ limit: String(limit), cursor: String(at), q: query, customer_type: type, identity, rule, status: triageStatus }).toString(); }
  useEffect(() => {
    const abort = new AbortController(); setPage(null);
    request<Page>((token ? '/api/operator/bulk/cases?' : '/api/demo/bulk/cases?') + parameters(), token, { signal: abort.signal }).then(value => {
      if (abort.signal.aborted) return; setPage(value); setSelected(old => value.items.some(r => r.id === old) ? old : value.items[0]?.id || '');
    }).catch(e => { if (!abort.signal.aborted) onError(e); });
    return () => abort.abort();
  }, [query, type, identity, rule, cursor, token, triageStatus, version]);
  useEffect(() => {
    const abort = new AbortController(); setCurrent(null);
    if (selected) request<CaseRecord>(`/api/${token ? 'operator' : 'demo'}/bulk/cases/${selected}`, token, { signal: abort.signal }).then(value => { if (!abort.signal.aborted) setCurrent(value); }).catch(e => { if (!abort.signal.aborted) onError(e); });
    return () => abort.abort();
  }, [selected, token, version]);
  function filter(fn: () => void) { navigate(() => { fn(); setCursor(0); setPrevious([]); setPreview(null); }); }
  async function perform(name: string, action: () => Promise<void>) {
    if (busy) return; const owner = token; setBusy(name); setMessage('');
    try { await action(); } catch (e) { if (live.current && session.current === owner) onError(e); }
    finally { if (live.current && session.current === owner) setBusy(''); }
  }
  async function inspect(single = false) {
    await perform('preview', async () => {
      const rows: Row[] = []; let next = 0;
      if (single) { const found = page?.items.find(r => r.id === selected); if (found) rows.push(found); }
      else do {
        const result = await request<Page>((token ? '/api/operator/bulk/cases?' : '/api/demo/bulk/cases?') + parameters(100, next), token);
        rows.push(...result.items.filter(row => row.rules.length > 0 && (token || !predictions[row.id])).slice(0, size - rows.length));
        if (result.next_cursor === null || rows.length >= size) break;
        next = result.next_cursor;
      } while (live.current);
      if (!rows.length) { setMessage('No eligible cases remain in this filter.'); return; }
      const result = token ? await request<Preview>('/api/operator/triage-batches/preview', token, { method: 'POST', body: JSON.stringify({ case_ids: rows.map(r => r.id) }) }) : null;
      if (result && !result.eligible_cases) { setMessage('No new eligible alerts remain in these cases. Choose Not fully triaged or another filter.'); return; }
      if (live.current && session.current === token) setPreview({ rows, live: result, single, key: crypto.randomUUID() });
    });
  }
  async function start() {
    if (!preview || !summary) return;
    const selectedPreview = preview;
    await perform('run', async () => {
      if (token && selectedPreview.live) {
        const result = await request<Job>('/api/operator/triage-batches', token, { method: 'POST', body: JSON.stringify({
          case_ids: selectedPreview.rows.map(r => r.id), dataset_id: selectedPreview.live.dataset_id,
          selection_hash: selectedPreview.live.selection_hash, idempotency_key: selectedPreview.key }) });
        if (live.current && session.current === token) { setPreview(null); setJob(result); setMessage('Batch saved. The separate worker processes eligible cases when verified access and daily controls allow.'); }
      } else {
        for (const row of selectedPreview.rows) {
          if (!live.current || session.current !== token) break;
          const output = Object.fromEntries(row.rules.map(r => [r, syntheticLabel(row.heuristic_score, row.requires_review, summary.policy.rules[r].tp, summary.policy.rules[r].fp)]));
          setPredictions(previous => ({ ...previous, [row.id]: output }));
          await new Promise<void>(resolve => window.setTimeout(resolve, 0));
        }
        if (live.current && session.current === token) { setPreview(null); setMessage('Synthetic batch triaged. Predictions await review; no Gemini calls or human verdicts were created.'); }
      }
    });
  }
  async function refresh() {
    await perform('refresh', async () => { if (job) setJob(await request<Job>('/api/operator/triage-batches/' + job.id, token)); setVersion(v => v + 1); });
  }
  function status(alert: PrivateAlert['alert']) {
    if (alert.feedback_revision > (reviewedRevisions.current.get(alert.id) || 0)) {
      reviewedRevisions.current.set(alert.id, alert.feedback_revision);
      request<typeof genuine>('/api/operator/bulk/summary', token).then(value => {
        if (live.current && session.current === token) setGenuine(value);
      }).catch(e => { if (live.current && session.current === token) onError(e); });
    }
    setCurrent(old => old && ({ ...old, alerts: old.alerts.map(a => a.id === alert.id ? { ...a, status: alert.status, frozen: alert.feedback_revision > 0, actionable: alert.feedback_revision === 0 && !['COMPLETE', 'RUNNING', 'QUEUED'].includes(alert.status) } : a) }));
  }
  async function learn(action?: string) {
    await perform('learning', async () => {
      const path = '/api/operator/bulk/learning' + (action && learning ? `/${learning.id}/${action}` : '');
      const result = await request<Learning>(path, token, { method: 'POST', body: JSON.stringify(action && learning ? { expected_revision: learning.revision } : {}) });
      if (live.current) { setLearning(result); setVersion(v => v + 1); }
    });
  }
  const simulated = Object.keys(predictions).length;
  const totalAlerts = summary ? Object.values(summary.rule_alerts).reduce((a, b) => a + b, 0) : 0;
  return <>
    <div className="metrics bulk-metrics">
      {[
        ['Dataset', summary?.transactions.toLocaleString() || 'Loading', `${summary?.identities || 0} identities / 40,000 candidate cases`],
        ['Triage progress', token ? String(genuine.triaged_cases) : String(simulated), token ? `Genuine triaged cases / ${summary?.eligible_pending_cases || 0} eligible; ${genuine.triaged_alerts} triaged alerts` : `Simulated cases / ${summary?.eligible_pending_cases || 0} eligible; ${totalAlerts.toLocaleString()} source alerts across all partitions`],
        [token ? 'Analyst FP share' : 'Training detector FPR', token ? (genuine.true_positive + genuine.false_positive ? `${(100 * genuine.false_positive / (genuine.true_positive + genuine.false_positive)).toFixed(1)}%` : 'Not available') : summary ? `${(100 * summary.training_detector_metrics.FP / (summary.training_detector_metrics.FP + summary.training_detector_metrics.TN)).toFixed(1)}%` : 'Not available', token ? `FP / (TP + FP), ${genuine.true_positive + genuine.false_positive} conclusive human reviews; ${genuine.inconclusive} inconclusive` : 'Synthetic training only: FP / (FP + TN). Validation is sealed; this is not A0 label accuracy.'],
        [token ? 'Analyst review' : 'Reference annotations', token ? String(genuine.reviewed_alerts) : '20,000', token ? 'Frozen human-reviewed alerts; simulation labels are excluded' : '16,000 training / 4,000 sealed validation; not human reviews'],
      ].map(([title, value, detail]) => <section className="metric" key={title}><span className="eyebrow">{title}</span><strong>{value}</strong><small>{detail}</small></section>)}
    </div>
    <div className="notice"><Icon name="info" size={17} /><span><strong>{token ? 'Operator genuine execution' : 'Synthetic simulation / 0 model calls'}.</strong> {token ? 'A batch contains up to 100 cases. Access, expiry and daily controls still apply.' : 'Progress belongs to this tab and resets on reload. Sealed validation references remain private.'}</span></div>
    <section className="panel bulk-queue"><div className="panel-heading"><h2><span aria-hidden="true">📋 </span>Bulk investigation queue</h2><span>{page?.total.toLocaleString() ?? 'Loading'} matching cases</span></div>
      {token && <button className="text-button" onClick={() => filter(() => { setTriageStatus('awaiting_review'); setQuery(''); setType(''); setIdentity(''); setRule(''); })}>Show cases awaiting analyst review</button>}
      <div className="bulk-filters">
        <label>Search identities<input value={query} onChange={e => { const value = e.target.value; filter(() => setQuery(value)); }} /></label>
        <label>Identity type<select aria-label="Identity type" value={type} onChange={e => { const value = e.target.value; filter(() => { setType(value); setIdentity(''); }); }}><option value="">All identity types</option><option value="INDIVIDUAL">Individuals</option><option value="ORGANIZATION">Organizations</option></select></label>
        <label>Identity<select aria-label="Identity" value={identity} onChange={e => { const value = e.target.value; filter(() => setIdentity(value)); }}><option value="">All identities</option>{identities.filter(r => !type || r.customer_type === type).map(r => <option key={r.identity_id} value={r.identity_id}>{r.name}</option>)}</select></label>
        <label>Detector rule<select aria-label="Detector rule" value={rule} onChange={e => { const value = e.target.value; filter(() => setRule(value)); }}><option value="">All nine rules</option>{Object.keys(summary?.rule_alerts || {}).map(r => <option key={r} value={r}>{names(r)}</option>)}</select></label>
        {token && <label>Triage status<select aria-label="Triage status" value={triageStatus} onChange={e => { const value = e.target.value; filter(() => setTriageStatus(value)); }}><option value="all">All cases</option><option value="awaiting_triage">Not fully triaged</option><option value="awaiting_review">Triaged, awaiting review</option><option value="frozen">Frozen human reviews</option></select></label>}
      </div>
      {!page ? <p role="status">Loading case summaries...</p> : !page.items.length ? <p>No matching cases. <button className="text-button" onClick={() => filter(() => { setQuery(''); setType(''); setIdentity(''); setRule(''); })}>Clear filters</button></p> : <div className="table-scroll bulk-table"><table><thead><tr><th>Identity / case</th><th>Rules</th><th>Source risk</th><th>{token ? 'Investigation state' : 'Simulation state'}</th></tr></thead><tbody>{page.items.map(row => <tr key={row.id} className={selected === row.id ? 'selected-row' : ''}><td><button aria-pressed={selected === row.id} className="text-button" onClick={() => navigate(() => setSelected(row.id))}>{row.name} / {row.id.slice(0, 6)}</button><small>{names(row.customer_type)}</small></td><td>{row.rules.map(names).join(', ') || 'No detector alert'}</td><td>{names(row.risk_tier)} {row.requires_review && <span className="badge neutral">Context / protected guard</span>}</td><td>{token ? row.reviewed ? 'Frozen human review' : row.triaged ? 'Triaged / awaiting review' : 'Pending triage' : predictions[row.id] ? Object.values(predictions[row.id]).map(names).join(', ') : 'Not simulated in this tab'}</td></tr>)}</tbody></table></div>}
      <div className="bulk-actions"><button disabled={!previous.length} onClick={() => navigate(() => { setCursor(previous[previous.length - 1]); setPrevious(p => p.slice(0, -1)); })}>Previous page</button><button disabled={!page?.next_cursor} onClick={() => navigate(() => { setPrevious(p => [...p, cursor]); setCursor(page!.next_cursor!); })}>Next page</button><span>50 summaries per page; transaction histories load on selection.</span></div>
    </section>
    {current && <section className="panel"><h2>{current.name}</h2><p>{current.evidence.customer.profile_context}</p><p>{current.alerts.length} source alerts / {current.evidence.history.length} prior transactions in the available 90-day trail.</p>{current.evidence.protected_signals.length > 0 && <p className="protected">Protected signals: {current.evidence.protected_signals.join(', ')}. These require analyst attention regardless of score.</p>}
      <details><summary>Source evidence and transaction trail</summary><p>Identity: {current.evidence.customer.display_name} / account {current.evidence.account.id.slice(0, 8)}</p><div className="table-scroll transaction-scroll"><table><thead><tr><th>Date</th><th>Movement</th><th>AUD minor units</th></tr></thead><tbody>{[...current.evidence.history, current.evidence.trigger].map(tx => <tr key={tx.id}><td>{new Date(tx.occurred_at).toLocaleDateString('en-AU')}</td><td>{tx.type}</td><td>{tx.amount_aud_minor.toLocaleString()}</td></tr>)}</tbody></table></div></details>
    <CaseStages current={current} token={token} /></section>}
    <section className="panel investigation-stage"><span className="eyebrow">INVESTIGATE / BATCH TRIAGE</span><h2>Build the investigation brief.</h2>
      <div className="bulk-actions"><label>Cases per batch<input aria-label="Cases per batch" type="number" min={1} max={100} value={size} onChange={e => setSize(Number(e.target.value))} /></label><button className="primary" disabled={!!busy || size < 1 || size > 100 || !Number.isInteger(size)} onClick={() => void inspect()}>Preview {token ? 'Gemini' : 'synthetic'} batch</button>{token && <button disabled={!!busy || !current?.alerts.some(a => a.actionable !== false)} onClick={() => void inspect(true)}>Check live triage</button>}</div>
      <p className="muted">Cases are triaged before analyst review. Reference annotations and synthetic predictions never complete a human review.</p>
      {message && <p role="status">{message}</p>}{busy && <p role="status">Working: {busy}...</p>}
      {token && batchHistory.length > 0 && <div className="form-field"><label htmlFor="bulk-job-history">Stored case batches</label><select id="bulk-job-history" value={job?.id || ''} onChange={e => { const id = e.target.value; if (id) void perform('batch', async () => setJob(await request<Job>('/api/operator/triage-batches/' + id, token))); }}><option value="">Select a stored batch</option>{batchHistory.map(r => <option key={r.id} value={r.id}>{names(r.state)} / {r.id.slice(0, 8)}</option>)}</select></div>}
      {job && <section className="batch-progress"><h3>Batch: {names(job.state)}</h3><p>{Object.entries(job.counts).map(([name, value]) => `${names(name)}: ${value}`).join(' / ')}</p><div className="bulk-actions"><button disabled={!!busy} onClick={() => void refresh()}>Refresh batch progress</button>{['pause', 'resume', 'cancel'].map(action => <button key={action} disabled={!!busy || ['COMPLETE', 'FAILED', 'CANCELLED'].includes(job.state)} onClick={() => setConfirmation({ title: action === 'resume' && job.state === 'PAUSED_OUTCOME' ? 'Acknowledge failures and continue remaining cases?' : `${names(action)} this batch?`, action: async () => { await perform(action, async () => setJob(await request<Job>(`/api/operator/triage-batches/${job.id}/${action}`, token, { method: 'POST', body: JSON.stringify({ expected_revision: job.revision, acknowledge_failed: action === 'resume' && job.state === 'PAUSED_OUTCOME' }) }))); } })}>{names(action)}</button>)}</div><details><summary>Case outcomes</summary>{job.members.map(m => <p key={m.case_id}>{m.case_id.slice(0, 8)}: {names(m.state)} {m.error_code || ''} {m.parent_id && <button className="text-button" onClick={() => onRun(m.parent_id!)}>Inspect run usage</button>}</p>)}</details></section>}
    </section>
    {token && current && <OperatorReview key={current.id} current={current} token={token} version={version} onError={onError} onDirty={onDirty} navigate={navigate} onRun={onRun} onComplete={onComplete} onStatus={status} />}
    {token && <section className="panel synthetic-learning"><h2><span aria-hidden="true">🧬 </span>Synthetic cutoff learning</h2><p>Fit on 16,000 reference-annotated training transactions; freeze before opening the separate 4,000-transaction validation cohort. This never changes genuine review counts or operational policy.</p><button className="primary" disabled={!!busy} onClick={() => void learn()}>Prepare synthetic candidates</button>{learningHistory.length > 0 && <div className="form-field"><label htmlFor="synthetic-history">Stored synthetic learning</label><select id="synthetic-history" value={learning?.id || ''} onChange={e => setLearning(learningHistory.find(r => r.id === e.target.value) || null)}><option value="">Select a frozen learning run</option>{learningHistory.map(r => <option key={r.id} value={r.id}>{names(r.state)} / {r.id.slice(0, 8)}</option>)}</select></div>}{learning && <><p>State: {names(learning.state)}</p><div className="table-scroll"><table><thead><tr><th>Rule</th><th>Eligible scored observations</th><th>Training result</th><th>Independent validation</th></tr></thead><tbody>{learning.body.results.map(r => <tr key={r.rule_id}><td>{names(r.rule_id)}</td><td>{r.sample_size} {!r.generator_target_met && '(cohort target unmet)'}</td><td>{names(r.status)}</td><td>{learning.validation?.results.find(v => v.rule_id === r.rule_id)?.passed ? 'Passed' : learning.validation ? 'Not supported' : 'Not opened'}</td></tr>)}</tbody></table></div><div className="bulk-actions">{['validate', 'approve', 'reject', 'apply'].map(action => <button key={action} disabled={!!busy || action === 'validate' && !!learning.validation || action === 'apply' && learning.state !== 'APPROVED' || ['approve', 'reject'].includes(action) && learning.state !== 'PROPOSED'} onClick={() => setConfirmation({ title: `${names(action)} synthetic candidates?`, action: () => learn(action) })}>{names(action)}</button>)}</div></>}</section>}
    {token && <section className="panel"><h2>Genuine bulk outcomes and A5</h2><p>Only frozen human reviews of genuine investigations count. Large evidence sets are frozen in immutable chunks; A5 receives measured aggregates and at most three supporting examples.</p>{reportHistory.length > 0 && <div className="form-field"><label htmlFor="bulk-report-history">Stored genuine bulk A5</label><select id="bulk-report-history" value={report?.run.id || ''} onChange={e => { const id = e.target.value; if (id) void perform('report', async () => setReport(await request<EvolutionDetail>('/api/operator/bulk/reports/' + id, token))); }}><option value="">Select a genuine report</option>{reportHistory.map(r => <option key={r.id} value={r.id}>{names(r.state)} / {r.id.slice(0, 8)}</option>)}</select></div>}<div className="bulk-actions"><button disabled={!!busy} onClick={() => void perform('snapshot', async () => { const result = await request<{ id: string }>('/api/operator/bulk/snapshots', token, { method: 'POST' }); setSnapshotId(result.id); setMessage('Genuine bulk evidence frozen. Synthetic annotations were excluded.'); })}>Freeze genuine bulk outcomes</button><button disabled={!!busy || !snapshotId} onClick={() => setConfirmation({ title: 'Run genuine A5 on this snapshot?', action: () => perform('A5', async () => setReport(await request<EvolutionDetail>('/api/operator/bulk/reports', token, { method: 'POST', body: JSON.stringify({ snapshot_id: snapshotId }) }))) })}>Run genuine bulk A5</button>{report && <button disabled={!!busy} onClick={() => void perform('report', async () => setReport(await request<EvolutionDetail>('/api/operator/bulk/reports/' + report.run.id, token)))}>Refresh bulk report</button>}</div>{report && <><p>Report: {names(report.run.state)} {report.run.error_code || ''}</p>{report.result && <><h3>{names(report.result.status)}</h3><p>{report.result.summary}</p>{report.result.findings?.map(item => <article className="analysis-block" key={item.rule_id + item.title}><h3>{item.title}</h3><p>{item.explanation}</p><p>Rule: {names(item.rule_id)} / {item.support_feedback_ids.length} cited supporting reviews.</p></article>)}{report.result.recommendation_items?.map(item => <article className="analysis-block" key={item.rule_id + item.title}><h3>{item.title}</h3><p>{item.rationale}</p><span className="badge neutral">{names(item.kind)} / operator approval required</span></article>)}<p>{report.result.conclusive_reviews} genuine conclusive reviews / {report.result.target_rule_reviews} target-rule reviews.</p><ul>{report.result.limitations.map(text => <li key={text}>{text}</li>)}</ul></>}<AgentTrace detail={report} /></>}</section>}
    {token && accounting && <section className="panel"><h2>Genuine bulk usage</h2><UsageDisplay usage={accounting} /></section>}
    {preview && <Dialog title={token ? 'Start genuine case batch?' : 'Run synthetic simulation?'} description={token ? 'The separate worker uses verified authorization and the daily allowance. This creates no human verdict.' : 'This computes heuristic predictions in this tab with zero model requests. It does not create a Gemini investigation.'} onClose={() => setPreview(null)}><p>{preview.rows.length} selected cases / {preview.rows.reduce((n, r) => n + r.rules.length, 0)} generated source alerts / {preview.rows.filter(r => r.requires_review).length} context or protected guards.</p>{preview.live && <p>{preview.live.eligible_cases} eligible cases / {preview.live.alerts} pending alerts / {preview.live.minimum_generation_attempts}-{preview.live.maximum_generation_attempts} generation attempts. Cost estimate unavailable. {preview.live.authorization_available ? '' : 'Live authorization is currently disabled; the job will wait for verified worker access.'}</p>}<button className="primary" onClick={() => void start()} disabled={!!busy}>Start batch</button></Dialog>}
    {confirmation && <Dialog title={confirmation.title} description="This explicit action preserves frozen records and uses revision checks. Synthetic changes apply only to the simulation." onClose={() => setConfirmation(null)}><button className="primary" onClick={() => { const action = confirmation.action; setConfirmation(null); void action(); }}>Confirm action</button></Dialog>}
  </>;
}
