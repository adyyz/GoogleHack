"""Chunked, immutable bulk evidence; only bounded examples enter A5 prompts."""
from collections import Counter, defaultdict
from google.cloud import firestore
from google.api_core.exceptions import AlreadyExists
from .bulk_dataset import ID, corpus
from .dataset import content_hash
from .engine import RULES
from .evolution import analytical_inputs, sufficiency
from .repository import Repository, Conflict, now
from .usage import summarize


def pages(repo, collection, filters=(), size=500):
    cursor = None
    while True:
        page = repo.page(collection, size, cursor, [("dataset_id", ID), *filters])
        if page["items"]: yield page["items"]
        cursor = page["next_cursor"]
        if not cursor: break


def usage(repo):
    """Reduce bounded ledger pages. Unknown categories remain unknown."""
    totals, known, reported = Counter(), Counter(), set()
    chart = True; categories = Counter()
    for rows in pages(repo, "step_runs"):
        part = summarize(rows)
        totals["ledger_rows"] += len(rows)
        totals["succeeded_rows"] += sum(row["state"] == "SUCCEEDED" for row in rows)
        for key in ("known_estimated_usd_micros", "unknown_attempts", "not_applicable_attempts", "provider_attempts"):
            totals[key] += part[key]
        if part["total_tokens"] is not None: totals["total_tokens"] += part["total_tokens"]; reported.add("total_tokens")
        for key, value in part["known_categories"].items():
            if value is not None: known[key] += value; reported.add(key)
        if part["categories"] is None and any(row.get("usage_status") == "PROVIDER_REPORTED" for row in rows): chart = False
        elif part["categories"] is not None: categories.update(part["categories"])
    empty = summarize([])
    return {**empty, **totals, "total_tokens": totals["total_tokens"] if "total_tokens" in reported else None,
        "known_categories": {key: known[key] if key in reported else None for key in empty["known_categories"]},
        "categories": dict(categories) if chart and categories else None}


class AnalyticsRepository(Repository):
    def __init__(self, settings): super().__init__(settings, ID)

    def freeze_analytical_inputs(self, actor):
        from .bulk_jobs import BulkRepository
        counts, groups = Counter(), defaultdict(Counter)
        chunks, examples, sample_steps, sample_alerts, cases, customers = [], [], [], [], {}, {}
        reviewed_cases = set()
        metric_totals, metric_groups = Counter(), defaultdict(lambda: defaultdict(Counter))
        cutoff = now()
        for events in pages(self, "feedback_events"):
            references = []
            for event in events:
                if event["submitted_at"] > cutoff: continue
                if event.get("provenance") != "HUMAN_OPERATOR": raise Conflict("Bulk analytics accepts genuine human reviews only")
                worker = BulkRepository(self.settings, event["case_id"])
                worker.db = self.db
                alert = worker.get("alerts", event["alert_id"]); run = worker.get("pipeline_runs", event["triage_run_id"])
                if not alert or alert["dataset_id"] != ID or not run or run["dataset_id"] != ID or run["state"] != "COMPLETE" or run["alert_id"] != alert["id"]:
                    raise Conflict("Bulk feedback lineage failed")
                @firestore.transactional
                def chain(tx): return worker._sealed_chain(tx, run)
                steps = chain(self.db.transaction(read_only=True))
                if alert.get("feedback_revision") != event["revision"]: raise Conflict("Bulk feedback is not frozen")
                references.append({"id": event["id"], "hash": content_hash(event), "run_id": run["id"], "alert_id": alert["id"]})
                counts[event["verdict"]] += 1; groups[alert["rule_id"]][event["verdict"]] += 1; reviewed_cases.add(event["case_id"])
                from .review_metrics import review_summary
                source = corpus().row(event["case_id"])
                one_case = {"id": event["case_id"], "customer_id": source["identity_id"], "split": "CALIBRATION_DISCOVERY"}
                one_customer = {"id": source["identity_id"], "customer_type": source["customer_type"]}
                one = review_summary([one_case], [one_customer], [alert], [event], steps)
                keys = ("reviewed_alerts", "true_positive", "false_positive", "inconclusive", "compared", "agreed", "suggestion_unavailable", "machine_uncertain")
                metric_totals.update({key: one[key] for key in keys})
                for dimension, values in one["groups"].items():
                    for value in values: metric_groups[dimension][value["name"]].update({key: value[key] for key in keys})
                if len(examples) < 3:
                    examples.append(event); sample_steps.extend(steps); sample_alerts.append(alert)
                    case = worker.operational_case(event["case_id"]); cases[case["id"]] = case
                    data = worker.load_dataset(); customers.update({k: v.model_dump() for k, v in data.customers.items()})
            if references:
                chunk_id = content_hash(references)
                try: self.create("bulk_evidence_chunks", chunk_id, {"dataset_id": ID, "references": references})
                except AlreadyExists:
                    if self.get("bulk_evidence_chunks", chunk_id)["references"] != references: raise Conflict("Evidence chunk changed")
                chunks.append({"id": chunk_id, "count": len(references)})
        if not sum(counts.values()): raise Conflict("Genuine bulk analyst feedback is required; synthetic annotations do not count")
        from .rule_intelligence import statistics
        computed = statistics(list(cases.values()), list(customers.values()), sample_alerts, examples, sample_steps)
        total = sum(counts.values()); conclusive = counts["TRUE_POSITIVE"] + counts["FALSE_POSITIVE"]
        computed.update(total_cases=40000, demo_cases=0, total_identities=500, total_alerts=sum(corpus().manifest["rule_alerts"].values()),
            reviewed_cases=len(reviewed_cases), reviewed_alerts=total, true_positive=counts["TRUE_POSITIVE"],
            false_positive=counts["FALSE_POSITIVE"], inconclusive=counts["INCONCLUSIVE"], scope="BULK_GENUINE_REVIEWS")
        computed.update(dict(metric_totals))
        computed["agreement_rate"] = metric_totals["agreed"] / metric_totals["compared"] if metric_totals["compared"] else None
        computed["groups"] = {dimension: [{"name": name, **dict(values),
            "agreement_rate": values["agreed"] / values["compared"] if values["compared"] else None} for name, values in grouped.items()]
            for dimension, grouped in metric_groups.items()}
        body = analytical_inputs(corpus().manifest["manifest_hash"], examples, sample_steps, sample_alerts, computed)
        accounting = usage(self)
        body["sample_sizes"].update(succeeded_steps=accounting.pop("succeeded_rows", 0), usage_steps=accounting.pop("ledger_rows", 0))
        body["sample_sizes"].update(feedback_events=total, reviewed_alerts=total, conclusive_reviews=conclusive, inconclusive_reviews=counts["INCONCLUSIVE"])
        body.update(bulk_reference_chunks=chunks, feedback_examples_omitted=total - len(examples),
            rules={rule: {**sufficiency(conclusive, group["TRUE_POSITIVE"] + group["FALSE_POSITIVE"]),
                "true_positive_reviews": group["TRUE_POSITIVE"], "false_positive_reviews": group["FALSE_POSITIVE"],
                "reviewed_alert_noise_proportion": group["FALSE_POSITIVE"] / (group["TRUE_POSITIVE"] + group["FALSE_POSITIVE"]) if group["TRUE_POSITIVE"] + group["FALSE_POSITIVE"] else None}
                for rule, group in groups.items()}, detector_gate=sufficiency(conclusive, groups["HIGH_VALUE"]["TRUE_POSITIVE"] + groups["HIGH_VALUE"]["FALSE_POSITIVE"]), usage=accounting)
        ident = content_hash(body)
        try: self.create("analytical_snapshots", ident, {"dataset_id": ID, "content_hash": ident, "body": body, "created_by": actor})
        except AlreadyExists: pass
        return self.get("analytical_snapshots", ident)

    def evolution_context(self, snapshot_id):
        snapshot = self.get("analytical_snapshots", snapshot_id)
        if snapshot:
            for reference in snapshot["body"].get("bulk_reference_chunks", []):
                chunk = self.get("bulk_evidence_chunks", reference["id"])
                if not chunk or content_hash(chunk["references"]) != reference["id"]: raise Conflict("Bulk evidence manifest changed")
                for item in chunk["references"]:
                    event = self.get("feedback_events", item["id"])
                    if not event or content_hash(event) != item["hash"]: raise Conflict("Frozen bulk review changed")
        return super().evolution_context(snapshot_id)

    def list(self, collection, dataset_id=None):
        if collection == "step_runs": return []  # A5 trace is fetched by run in evolution_detail below.
        return super().list(collection, dataset_id)

    def evolution_detail(self, run_id):
        from .agent_views import agent_trace
        result = super().evolution_detail(run_id)
        result["agent_trace"] = agent_trace(self.usage_steps(run_id), run_id, ("A5",))
        return result
