# Updated Genesis build candidate

PREPARED_NOT_SUBMITTED. Source fingerprint: 558ac42410d2eb7d9a84056cc0aa33c24e54e48e396a76107cc9e4f00c789148.
Local validation:82 unit passes;11 fresh emulator integration passes,zero integration skips;
frontend production build and browser journeys passed. These are not new Linux image results.
The previous6cd03 build and digests remain historical and unchanged.

This candidate reuses the verified user-managed build identity, Sydney image registry,
four-step build/integrity/network-isolated-smoke configuration, E2_STANDARD_2 and1200s timeout.
No model key, credentials, caches, internal context, local dashboard or source data is included.
Run verify-package.py locally to check all files. New image digests are unknown until a new
explicitly approved build succeeds. No build, deployment or model request has been submitted.
The previous one-build approval has been consumed. See next-deployment-plan.json in the
private Genesis .cache/build directory for the proposed bounded staging scope and cost gates.
