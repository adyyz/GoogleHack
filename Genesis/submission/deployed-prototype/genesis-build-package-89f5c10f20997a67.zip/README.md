# Genesis build package

PREPARATION_ONLY. Prepared from the verified source ZIP, SHA256 089d4d4d3fe5dc7d0f831a66598b6d5b1b111b30460887c97dc2778726834540.
Code fingerprint: 6cd03b64cc2d6616ee4ba4465c301453520c5a4bf572ff7b63e49549ccbaf426. Base Git revision: c5595b958896c93455bc57bd60cfc6e70292e2dd.
The source worktree was uncommitted. This fingerprint is not a release commit or image digest.
Recorded native checks: 70 unit passes, 11 fresh emulator integration passes (zero skips),
production build and browser journeys passed. Image builds/startup remain UNVERIFIED.

## Contents and local verification

source/ is a minimal Docker context: the original pinned multi-stage Dockerfile, runtime
Python/frontend source and frozen locks. No environments, keys, logs, emulator exports,
private context, model output, human reviews, submission binaries or node_modules are included.
build-manifest.json records every packaged file hash. Verify the ZIP SHA256 before extraction,
then run Python 3.12 against verify-package.py. It uses only the standard library and no network.

From the extracted package directory (kept under Genesis), the later local build commands are:

    docker build --platform linux/amd64 --target web -t genesis-web:local source
    docker build --platform linux/amd64 --target worker -t genesis-worker:local source

Run both images and record actual image digests, startup, health/auth and non-root checks before
claiming container verification. Docker/Podman is currently unavailable. Package integrity and
native tests do not prove Linux image behavior. No engine was installed during packaging.

## Optional Google Cloud Build route -- not submitted

cloudbuild.example.json follows Google's current JSON configuration schema. It verifies this
package, builds two linux/amd64 targets sequentially and pushes web/worker images to:
australia-southeast1-docker.pkg.dev/genesis-aicb/genesis-demo-images
Tags carry the full verified source fingerprint. Obtain actual image digests from build results
and use digest references for the separate deployment. This build config never deploys services,
publishes source data, calls a model or retrieves an application secret.

Cloud Build was not part of the previous local-build route. Preparing this alternative does not
waive local image testing or authorize a billed build. Before any submission, verify Cloud Build,
source staging/storage, Artifact Registry and log coverage; approve the exact build identity,
source staging bucket/region, API setup and bounded build cost. Do not assume promotional credits,
a free allowance or an existing default service account covers these services.

Replace _BUILD_SERVICE_ACCOUNT only with the approved same-project build account email after
reviewing its source-bucket access, repository-scoped Artifact Registry Writer and log permissions.
Use a build identity with the required build permissions; runtime/model identities are not chosen
automatically. The placeholder is deliberately not a working account. No IAM/API/resource change
or model secret is needed for offline package verification.

The future submit form, from Genesis, is the existing scripts/gcloud.ps1 wrapper's builds submit
command with the extracted package as source, cloudbuild.example.json as config, explicit project
genesis-aicb and reviewed region australia-southeast1. Do not run it before coverage, identity,
local image proof and the concrete cloud build are authorized. No trigger is configured.

## Runtime configuration remains separate

Keep AI/tasks disabled. Supply DEPLOYED_CODE_FINGERPRINT=6cd03b64cc2d6616ee4ba4465c301453520c5a4bf572ff7b63e49549ccbaf426 identically to web,
worker and the source publisher later. Real Firebase configuration, operator/admin UIDs, private
worker audience, queue identity, model/location, credits/expiry and reviewed rate card stay outside
this build context. Never bake Gemini keys or service-account credentials into an image.

Official references reviewed 17 October 2026:
https://docs.cloud.google.com/build/docs/build-config-file-schema
https://docs.cloud.google.com/build/docs/building/build-containers
https://docs.cloud.google.com/build/docs/securing-builds/configure-user-specified-service-accounts
