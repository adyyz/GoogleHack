#!/usr/bin/env bash
set -euo pipefail
web_name=genesis-build-web-smoke
worker_name=genesis-build-worker-smoke
cleanup() { docker rm -f "$web_name" "$worker_name" >/dev/null 2>&1 || true; }
trap cleanup EXIT
docker run --detach --network=none --name "$web_name" \
  -e APP_MODE=local -e GOOGLE_CLOUD_PROJECT=demo-aml-insight \
  -e LIVE_AI_ENABLED=false -e LOCAL_GEMINI_ENABLED=false -e CLOUD_TASKS_ENABLED=false -e CREDITS_VERIFIED=false "$1"
docker run --detach --network=none --name "$worker_name" \
  -e APP_MODE=cloud -e GOOGLE_CLOUD_PROJECT=genesis-aicb \
  -e WORKER_AUDIENCE=https://build-smoke.invalid \
  -e TASK_INVOKER_EMAIL=genesis-demo-tasks@genesis-aicb.iam.gserviceaccount.com \
  -e LIVE_AI_ENABLED=false -e LOCAL_GEMINI_ENABLED=false -e CLOUD_TASKS_ENABLED=false -e CREDITS_VERIFIED=false "$2"
check() {
  for attempt in $(seq 1 60); do
    if docker exec -i "$1" python - "$2" < container-smoke.py; then return 0; fi
    sleep 1
  done
  docker logs "$1"
  return 1
}
check "$web_name" web
check "$worker_name" worker
