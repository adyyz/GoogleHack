"""Run inside a network-isolated image; exercise startup without cloud/data calls."""
import json,os,sys
from urllib.request import Request,urlopen
from urllib.error import HTTPError
assert os.getuid()==65532 and os.getgid()==65532
for key in ('LIVE_AI_ENABLED','LOCAL_GEMINI_ENABLED','CLOUD_TASKS_ENABLED','CREDITS_VERIFIED'):
    assert os.environ[key]=='false'
assert not os.getenv('GEMINI_API_KEY')
base='http://127.0.0.1:8080'
if sys.argv[1]=='web':
    with urlopen(base+'/api/health',timeout=2) as response:
        body=json.load(response)
        assert body['status']=='ok' and body['mode']=='local' and body['live_ai_enabled'] is False
    with urlopen(base+'/',timeout=2) as response:
        assert response.status==200 and 'text/html' in response.headers['Content-Type']
        assert 'id="root"' in response.read().decode()
    request=Request(base+'/api/operator/session')
else:
    request=Request(base+'/internal/jobs',data=json.dumps({'run_id':'0'*24,'generation':1}).encode(),
        headers={'Content-Type':'application/json'},method='POST')
try:
    urlopen(request,timeout=2)
    raise AssertionError('Signed-out private access was accepted')
except HTTPError as error:
    assert error.code==401 and error.headers['Cache-Control']=='no-store'
print(json.dumps({'target':sys.argv[1],'non_root':True,'startup':True,'private_access_denied':True,
    'live_ai_enabled':False,'network_isolated':True}))
