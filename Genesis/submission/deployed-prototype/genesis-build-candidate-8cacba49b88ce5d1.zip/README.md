# Updated Genesis build candidate

PREPARED_NOT_SUBMITTED. Source fingerprint: 8cacba49b88ce5d1578a95869ce0795562b04d41d62b1cfb7ce8aeaf8150f31d.
Local validation:108 unit passes;16 fresh emulator integration passes,zero integration skips;
frontend production build, isolated browser journeys and genuine investigation browser read passed. These are not new Linux image results.
The deployed efd33 build and digests remain the verified private staging baseline.

This candidate reuses the verified user-managed build identity, Sydney image registry,
four-step build/integrity/network-isolated-smoke configuration, E2_STANDARD_2 and1200s timeout.
No model key, credentials, caches, internal context, local dashboard or source data is included.
Run verify-package.py locally to check all files. New image digests are unknown until a new
explicitly approved build succeeds. This packaging step submits no cloud job or model request.
Deploy the reviewed Firestore indexes before cloud feature verification. This package does not apply them.
The previous one-build approval has been consumed. See next-deployment-plan.json in the
private Genesis .cache/build directory for the proposed bounded staging scope and cost gates.
