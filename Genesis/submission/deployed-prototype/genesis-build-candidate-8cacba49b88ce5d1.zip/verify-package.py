"""Offline package integrity check; no cloud client or application import."""
import hashlib,json,os
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'build-manifest.json').read_text())
expected=os.getenv('EXPECTED_SOURCE_FINGERPRINT',manifest['source']['code_fingerprint'])
if expected != manifest['source']['code_fingerprint']: raise SystemExit('Source fingerprint mismatch')
for name,digest in manifest['files'].items():
    path=root/name
    if path.is_symlink() or not path.resolve().is_relative_to(root): raise SystemExit('Linked/escaping package file')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=digest: raise SystemExit('Package hash mismatch: '+name)
print(json.dumps({'status':'PACKAGE_INTEGRITY_VERIFIED','files':len(manifest['files']),
    'code_fingerprint':expected,'images_built':False,'cloud_submitted':False}))
